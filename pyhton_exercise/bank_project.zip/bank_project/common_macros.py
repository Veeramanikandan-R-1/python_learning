import os
curr_path=os.getcwd()
user_detail_json_path=curr_path+'\\{}'.format('user_details.json')
user_transaction_json_path=curr_path+'\\{}'.format('transaction_history.json')
account_no_json_path=curr_path+'\\{}'.format('account_no.json')