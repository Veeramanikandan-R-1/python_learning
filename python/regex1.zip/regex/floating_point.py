import re
number=input("enter a number\n")
condition=re.findall(r'^[+-]?[0-9]*.[0-9]+$',number)
print(condition)
if condition:
	print('true')
else:
	print('false')
